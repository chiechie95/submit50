#include <cs50.h>
#include <stdio.h>

int main(void)
{
    //get a number from user
   int x = get_int("x: ");
   int y = get_int("y: ");
   
    //result
   printf("%i\n", x + y);

}