#include <stdio.h>
int main(void)
{
     //Greet user
     printf("hello, world");
}